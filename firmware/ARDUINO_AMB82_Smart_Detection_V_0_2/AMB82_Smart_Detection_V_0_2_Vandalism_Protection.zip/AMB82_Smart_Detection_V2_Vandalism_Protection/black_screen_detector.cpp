// black_screen_detector.cpp - AMB82 Black Screen Detection Implementation - FIXED
#include "black_screen_detector.h"
#include "lora_rak3172.h"
#include "amb82_gpio.h"
#include "amb82_flash.h"

// ===== FIX: Define constants locally =====
#define LOCAL_NNWIDTH  576
#define LOCAL_NNHEIGHT 320

// ===== GLOBAL VARIABLES =====
black_screen_detector_t black_screen_detector = {0};

// Enhanced detector with additional statistics
typedef struct {
    uint32_t total_pixel_samples;
    float avg_pixel_brightness;
    float min_pixel_brightness;
    float max_pixel_brightness;
    uint32_t sample_points_x[16];
    uint32_t sample_points_y[16];
    uint8_t num_sample_points;
    bool use_enhanced_analysis;
} enhanced_stats_t;

enhanced_stats_t enhanced_stats = {0};

// ===== FIX: Forward function declarations =====
void enhanced_black_screen_handle_detection();
void enhanced_black_screen_reset_alert();
float analyze_enhanced_frame_brightness();
void setup_enhanced_sampling_points();

// ===== INITIALIZATION =====
black_screen_result_t black_screen_init() {
    INFO_PRINT("Initializing enhanced black screen detector...");
    
    // Initialize detector state
    black_screen_detector.enabled = system_config.black_screen_enabled;
    black_screen_detector.consecutive_black_frames = 0;
    black_screen_detector.last_check_time = 0;
    black_screen_detector.black_screen_start_time = 0;
    black_screen_detector.is_currently_black = false;
    black_screen_detector.alert_triggered = false;
    black_screen_detector.last_brightness_value = 1.0f;
    black_screen_detector.total_checks = 0;
    black_screen_detector.black_detections = 0;
    black_screen_detector.initialized = true;
    
    // Setup enhanced analysis
    setup_enhanced_sampling_points();
    
    INFO_PRINT("Enhanced black screen detector initialized");
    INFO_PRINT("- Enabled: " + String(black_screen_detector.enabled ? "YES" : "NO"));
    INFO_PRINT("- Threshold: " + String(system_config.black_screen_threshold, 3));
    INFO_PRINT("- Duration: " + String(system_config.black_screen_duration_ms/1000) + "s");
    INFO_PRINT("- Enhanced analysis: " + String(enhanced_stats.use_enhanced_analysis ? "ENABLED" : "DISABLED"));
    
    return BLACK_SCREEN_SUCCESS;
}

// ===== ENHANCED SAMPLING SETUP =====
void setup_enhanced_sampling_points() {
    enhanced_stats.num_sample_points = 16;  // 4x4 grid
    
    // Create a 4x4 grid of sampling points across the image
    int point_idx = 0;
    for (int row = 0; row < 4; row++) {
        for (int col = 0; col < 4; col++) {
            // Calculate relative positions using local constants
            enhanced_stats.sample_points_x[point_idx] = (col + 1) * (LOCAL_NNWIDTH / 5);
            enhanced_stats.sample_points_y[point_idx] = (row + 1) * (LOCAL_NNHEIGHT / 5);
            point_idx++;
        }
    }
    
    enhanced_stats.use_enhanced_analysis = true;
    enhanced_stats.min_pixel_brightness = 1.0f;
    enhanced_stats.max_pixel_brightness = 0.0f;
    
    INFO_PRINT("Enhanced sampling points configured: " + String(enhanced_stats.num_sample_points) + " points");
}

// ===== ENHANCED BRIGHTNESS ANALYSIS =====
float analyze_enhanced_frame_brightness() {
    enhanced_stats.total_pixel_samples++;
    
    // Get current neural network results
    std::vector<ObjectDetectionResult> results = ObjDet.getResult();
    int count = ObjDet.getResultCount();
    
    float brightness_score = 0.0f;
    
    // Enhanced Method: Detection-based brightness estimation with temporal analysis
    if (count > 0) {
        float total_confidence = 0.0f;
        float total_area_coverage = 0.0f;
        int high_confidence_detections = 0;
        
        for (int i = 0; i < count && i < 5; i++) {
            ObjectDetectionResult item = results[i];
            
            // Calculate detection area
            float width = item.xMax() - item.xMin();
            float height = item.yMax() - item.yMin();
            float area = width * height;
            
            total_confidence += item.score();
            total_area_coverage += area;
            
            // Count high-confidence detections
            if (item.score() > 0.7f) {
                high_confidence_detections++;
            }
        }
        
        // Enhanced scoring: confidence + coverage + quality
        float avg_confidence = total_confidence / count;
        float quality_bonus = (float)high_confidence_detections / count;
        
        brightness_score = (avg_confidence * 0.5f) + 
                          (total_area_coverage * 0.3f) + 
                          (quality_bonus * 0.2f);
        
        // Cap at 1.0
        if (brightness_score > 1.0f) brightness_score = 1.0f;
        
        // Reset consecutive no-detection counter
        static uint32_t consecutive_no_detection_frames = 0;
        static uint32_t last_good_detection_time = millis();
        consecutive_no_detection_frames = 0;
        last_good_detection_time = millis();
        
    } else {
        // No detections - enhanced temporal analysis
        static uint32_t consecutive_no_detection_frames = 0;
        static uint32_t last_good_detection_time = millis();
        
        consecutive_no_detection_frames++;
        uint32_t time_since_last_detection = millis() - last_good_detection_time;
        
        // Progressive darkening based on time and frame count
        if (consecutive_no_detection_frames > 50 && time_since_last_detection > 15000) {
            brightness_score = 0.02f;  // Very very dark (likely covered)
        } else if (consecutive_no_detection_frames > 25 && time_since_last_detection > 8000) {
            brightness_score = 0.05f;  // Very dark (possibly covered)
        } else if (consecutive_no_detection_frames > 15 && time_since_last_detection > 5000) {
            brightness_score = 0.12f;  // Dark (suspicious)
        } else if (consecutive_no_detection_frames > 8 && time_since_last_detection > 3000) {
            brightness_score = 0.25f;  // Moderately dark
        } else {
            brightness_score = 0.45f;  // Assume normal for very short periods
        }
    }
    
    // Update enhanced statistics
    if (enhanced_stats.total_pixel_samples == 1) {
        enhanced_stats.min_pixel_brightness = brightness_score;
        enhanced_stats.max_pixel_brightness = brightness_score;
        enhanced_stats.avg_pixel_brightness = brightness_score;
    } else {
        // Running average with more weight on recent samples
        enhanced_stats.avg_pixel_brightness = 
            (enhanced_stats.avg_pixel_brightness * 0.85f) + (brightness_score * 0.15f);
        
        if (brightness_score < enhanced_stats.min_pixel_brightness) {
            enhanced_stats.min_pixel_brightness = brightness_score;
        }
        if (brightness_score > enhanced_stats.max_pixel_brightness) {
            enhanced_stats.max_pixel_brightness = brightness_score;
        }
    }
    
    return brightness_score;
}

// ===== FRAME ANALYSIS =====
black_screen_result_t black_screen_analyze_frame() {
    if (!black_screen_detector.enabled || !black_screen_detector.initialized) {
        return BLACK_SCREEN_SUCCESS;
    }
    
    black_screen_detector.total_checks++;
    
    // Use enhanced brightness analysis
    float brightness = analyze_enhanced_frame_brightness();
    black_screen_detector.last_brightness_value = brightness;
    
    // Enhanced dark detection with hysteresis
    bool is_dark;
    if (black_screen_detector.is_currently_black) {
        // If already in black state, require higher brightness to exit (hysteresis)
        is_dark = (brightness < (system_config.black_screen_threshold + 0.05f));
    } else {
        // If not in black state, use normal threshold
        is_dark = (brightness < system_config.black_screen_threshold);
    }
    
    // Update consecutive frame counter
    if (is_dark) {
        black_screen_detector.consecutive_black_frames++;
        black_screen_detector.black_detections++;
        
        if (!black_screen_detector.is_currently_black) {
            // First dark frame detected
            black_screen_detector.is_currently_black = true;
            black_screen_detector.black_screen_start_time = millis();
            INFO_PRINT("🔴 Enhanced black screen started - brightness: " + String(brightness, 3) + 
                      " (threshold: " + String(system_config.black_screen_threshold, 3) + ")");
        }
    } else {
        // Frame is not dark
        if (black_screen_detector.is_currently_black) {
            // Black screen ended
            uint32_t duration = millis() - black_screen_detector.black_screen_start_time;
            black_screen_detector.is_currently_black = false;
            black_screen_detector.consecutive_black_frames = 0;
            
            INFO_PRINT("✅ Enhanced black screen ended - brightness: " + String(brightness, 3) + 
                      ", duration: " + String(duration/1000) + "s");
            
            // Reset alert if it was triggered
            if (black_screen_detector.alert_triggered) {
                enhanced_black_screen_reset_alert();
            }
        }
    }
    
    return BLACK_SCREEN_SUCCESS;
}

// ===== PROCESSING =====
void black_screen_process() {
    if (!black_screen_detector.enabled || !black_screen_detector.initialized) {
        return;
    }
    
    uint32_t current_time = millis();
    
    // Enhanced: Check every 2 seconds for more responsive detection
    if (current_time - black_screen_detector.last_check_time < 2000) {
        return;
    }
    
    black_screen_detector.last_check_time = current_time;
    
    // Analyze current frame
    black_screen_analyze_frame();
    
    // MAINTAIN LASER STATE DURING BLACK SCREEN EVENT
    if (black_screen_detector.is_currently_black && black_screen_detector.alert_triggered) {
        // Keep laser forced ON during entire black screen event
        if (gpio_is_initialized()) {
            gpio_laser_force_on();
        }
        
        // Send periodic vandalism alerts every 60 seconds
        static uint32_t last_periodic_alert = 0;
        if (current_time - last_periodic_alert > 60000) {
            if (lora_is_initialized()) {
                char ongoing_alert[70];
                snprintf(ongoing_alert, sizeof(ongoing_alert), 
                         "VANDALISM_ONGOING,%.3f,%lu", 
                         black_screen_detector.last_brightness_value,
                         (current_time - black_screen_detector.black_screen_start_time)/1000);
                lora_send_message(LORA_MSG_ALERT, ongoing_alert);
            }
            Serial.println("🔴 Enhanced vandalism event ongoing - laser active");
            last_periodic_alert = current_time;
        }
    }
    
    // Check if we should trigger an alert for the first time
    if (black_screen_detector.is_currently_black && 
        !black_screen_detector.alert_triggered) {
        
        uint32_t black_duration = current_time - black_screen_detector.black_screen_start_time;
        
        if (black_duration >= system_config.black_screen_duration_ms) {
            enhanced_black_screen_handle_detection();
        }
    }
}

// ===== ENHANCED DETECTION HANDLER =====
void enhanced_black_screen_handle_detection() {
    if (black_screen_detector.alert_triggered) {
        return; // Alert already active
    }
    
    black_screen_detector.alert_triggered = true;
    system_config.total_black_screen_events++;
    system_config.last_black_screen_time = millis();
    
    Serial.println("\n🚨🚨🚨 ENHANCED VANDALISM DETECTION ALERT! 🚨🚨🚨");
    Serial.println("📹 Camera covered or damaged - ENHANCED ANALYSIS CONFIRMED");
    Serial.println("⏱️ Duration: " + String(system_config.black_screen_duration_ms/1000) + " seconds");
    Serial.println("💡 Brightness: " + String(black_screen_detector.last_brightness_value, 3) + 
                   " (threshold: " + String(system_config.black_screen_threshold, 3) + ")");
    Serial.println("📊 Consecutive black frames: " + String(black_screen_detector.consecutive_black_frames));
    Serial.println("🔴 CROSSHAIR LASER ACTIVATED AS DETERRENT!");
    Serial.println("🎯 Enhanced analysis: " + String(enhanced_stats.total_pixel_samples) + " samples analyzed");
    
    // Create detection result for logging
    detection_result_t det_result = {0};
    det_result.timestamp = millis();
    det_result.object_class = CLASS_BLACK_SCREEN;
    det_result.confidence = 1.0f - black_screen_detector.last_brightness_value;
    det_result.x_min = 0;
    det_result.y_min = 0;
    det_result.x_max = 1;
    det_result.y_max = 1;
    det_result.valid = 1;
    
    // Log to flash
    if (flash_is_initialized()) {
        flash_write_detection_log(&det_result);
    }
    
    // ENHANCED VANDALISM DETERRENT SYSTEM ACTIVATION
    if (gpio_is_initialized()) {
        // Set aggressive alert pattern for black screen
        gpio_status_led_set_pattern(LED_PATTERN_FAST_BLINK);
        
        // FORCE CROSSHAIR LASER ON - VANDALISM DETERRENT
        gpio_laser_force_on();
        Serial.println("🎯 Crosshair laser FORCED ON as enhanced vandalism deterrent");
        
        // Disable normal fan operation during vandalism event
        gpio_fan_enable(false);
        Serial.println("🌀 Fan disabled during vandalism event");
    }
    
    // Send enhanced LoRa vandalism alert (FIX: Use %lu for uint32_t)
    if (lora_is_initialized()) {
        char alert_msg[80];
        snprintf(alert_msg, sizeof(alert_msg), 
                 "ENHANCED_VANDALISM,%.3f,%lu,LASER_ON,%lu", 
                 black_screen_detector.last_brightness_value,
                 system_config.black_screen_duration_ms/1000,
                 black_screen_detector.consecutive_black_frames);
        
        lora_result_t result = lora_send_message(LORA_MSG_ALERT, alert_msg);
        if (result == LORA_SUCCESS) {
            Serial.println("📡 Enhanced vandalism alert sent via LoRa");
        } else {
            Serial.println("❌ Failed to send enhanced vandalism alert via LoRa");
        }
    }
    
    Serial.println("🚨🚨🚨 ENHANCED VANDALISM PROTECTION ACTIVE 🚨🚨🚨\n");
}

// ===== ENHANCED ALERT RESET =====
void enhanced_black_screen_reset_alert() {
    if (black_screen_detector.alert_triggered) {
        uint32_t vandalism_duration = millis() - black_screen_detector.black_screen_start_time;
        
        black_screen_detector.alert_triggered = false;
        
        Serial.println("\n✅✅✅ ENHANCED BLACK SCREEN CLEARED ✅✅✅");
        Serial.println("📹 Normal camera vision RESTORED - enhanced analysis confirmed");
        Serial.println("🔴 CROSSHAIR LASER DEACTIVATED");
        Serial.println("⏱️ Total vandalism duration: " + String(vandalism_duration/1000) + " seconds");
        Serial.println("📊 Total black frames detected: " + String(black_screen_detector.consecutive_black_frames));
        Serial.println("💡 Final brightness: " + String(black_screen_detector.last_brightness_value, 3));
        
        // DEACTIVATE ENHANCED VANDALISM DETERRENT SYSTEM
        if (gpio_is_initialized()) {
            // Turn OFF the crosshair laser
            gpio_laser_force_off();
            
            // Reset status LED to normal operation
            gpio_status_led_set_pattern(LED_PATTERN_SLOW_BLINK);
            
            // Re-enable normal fan operation
            gpio_fan_enable(system_config.fan_enabled);
            
            Serial.println("🎯 All enhanced deterrent systems deactivated - normal operation resumed");
        }
        
        // Send enhanced recovery notification (FIX: Use %lu for uint32_t)
        if (lora_is_initialized()) {
            char recovery_msg[100];
            snprintf(recovery_msg, sizeof(recovery_msg), 
                     "VISION_RESTORED,LASER_OFF,%lu,%.3f,%lu", 
                     vandalism_duration/1000,
                     black_screen_detector.last_brightness_value,
                     black_screen_detector.consecutive_black_frames);
            lora_send_message(LORA_MSG_ALERT, recovery_msg);
            Serial.println("📡 Enhanced vision restoration notification sent via LoRa");
        }
        
        Serial.println("✅✅✅ ENHANCED NORMAL OPERATION RESUMED ✅✅✅\n");
    }
}

// ===== CONFIGURATION FUNCTIONS =====
black_screen_result_t black_screen_set_threshold(float threshold) {
    if (threshold < 0.0f || threshold > 1.0f) {
        return BLACK_SCREEN_ERROR_PROCESSING;
    }
    
    system_config.black_screen_threshold = threshold;
    INFO_PRINT("Enhanced black screen threshold set to " + String(threshold, 3));
    return BLACK_SCREEN_SUCCESS;
}

black_screen_result_t black_screen_set_duration(uint32_t duration_ms) {
    if (duration_ms < 1000 || duration_ms > 60000) {
        return BLACK_SCREEN_ERROR_PROCESSING;
    }
    
    system_config.black_screen_duration_ms = duration_ms;
    INFO_PRINT("Enhanced black screen duration set to " + String(duration_ms/1000) + " seconds");
    return BLACK_SCREEN_SUCCESS;
}

black_screen_result_t black_screen_enable(bool enable) {
    black_screen_detector.enabled = enable;
    system_config.black_screen_enabled = enable;
    
    if (!enable && black_screen_detector.alert_triggered) {
        enhanced_black_screen_reset_alert();
    }
    
    INFO_PRINT("Enhanced black screen detection " + String(enable ? "enabled" : "disabled"));
    return BLACK_SCREEN_SUCCESS;
}

// ===== STATUS FUNCTIONS =====
bool black_screen_is_enabled() {
    return black_screen_detector.enabled;
}

bool black_screen_is_alert_active() {
    return black_screen_detector.alert_triggered;
}

bool black_screen_is_laser_deterrent_active() {
    return black_screen_detector.alert_triggered && black_screen_detector.is_currently_black;
}

float black_screen_get_last_brightness() {
    return black_screen_detector.last_brightness_value;
}

uint32_t black_screen_get_detection_count() {
    return black_screen_detector.black_detections;
}

void black_screen_print_stats() {
    Serial.println("\n=== ENHANCED BLACK SCREEN DETECTOR STATS ===");
    Serial.println("Enabled: " + String(black_screen_detector.enabled ? "YES" : "NO"));
    Serial.println("Alert Active: " + String(black_screen_detector.alert_triggered ? "YES" : "NO"));
    Serial.println("Currently Black: " + String(black_screen_detector.is_currently_black ? "YES" : "NO"));
    Serial.println("Laser Active: " + String(black_screen_detector.alert_triggered ? "YES (DETERRENT)" : "NO"));
    Serial.println("Threshold: " + String(system_config.black_screen_threshold, 3));
    Serial.println("Duration: " + String(system_config.black_screen_duration_ms/1000) + "s");
    Serial.println("Last Brightness: " + String(black_screen_detector.last_brightness_value, 3));
    Serial.println("Total Checks: " + String(black_screen_detector.total_checks));
    Serial.println("Black Detections: " + String(black_screen_detector.black_detections));
    Serial.println("Total Events: " + String(system_config.total_black_screen_events));
    Serial.println("Consecutive Frames: " + String(black_screen_detector.consecutive_black_frames));
    
    // Enhanced statistics
    Serial.println("\n📊 ENHANCED ANALYSIS STATS:");
    Serial.println("Enhanced Analysis: " + String(enhanced_stats.use_enhanced_analysis ? "ENABLED" : "DISABLED"));
    Serial.println("Sample Points: " + String(enhanced_stats.num_sample_points));
    Serial.println("Total Samples: " + String(enhanced_stats.total_pixel_samples));
    Serial.println("Avg Brightness: " + String(enhanced_stats.avg_pixel_brightness, 3));
    Serial.println("Min Brightness: " + String(enhanced_stats.min_pixel_brightness, 3));
    Serial.println("Max Brightness: " + String(enhanced_stats.max_pixel_brightness, 3));
    
    if (black_screen_detector.is_currently_black) {
        uint32_t current_duration = (millis() - black_screen_detector.black_screen_start_time) / 1000;
        Serial.println("Current Event Duration: " + String(current_duration) + "s");
    }
    
    if (system_config.last_black_screen_time > 0) {
        Serial.println("Last Event: " + String((millis() - system_config.last_black_screen_time)/1000) + "s ago");
    } else {
        Serial.println("Last Event: Never");
    }
    
    Serial.println("\n🎯 ENHANCED VANDALISM DETERRENT STATUS:");
    if (black_screen_detector.alert_triggered) {
        Serial.println("🔴 ACTIVE - Enhanced crosshair laser deterrent is ON");
        Serial.println("⚠️  Laser will remain ON until vision is restored");
        Serial.println("🌀 Fan operation suspended during alert");
    } else {
        Serial.println("🟢 INACTIVE - Normal laser operation");
        Serial.println("🌀 Normal fan operation active");
    }
    
    Serial.println("===========================================\n");
}

// ===== MANUAL CONTROL FUNCTIONS =====
void black_screen_force_alert_test() {
    Serial.println("🧪 FORCING ENHANCED BLACK SCREEN ALERT FOR TESTING");
    black_screen_detector.is_currently_black = true;
    black_screen_detector.black_screen_start_time = millis() - system_config.black_screen_duration_ms;
    black_screen_detector.last_brightness_value = 0.02f;
    black_screen_detector.consecutive_black_frames = 100;
    enhanced_black_screen_handle_detection();
}

void black_screen_force_clear_test() {
    Serial.println("🧪 FORCING ENHANCED BLACK SCREEN CLEAR FOR TESTING");
    black_screen_detector.is_currently_black = false;
    black_screen_detector.last_brightness_value = 0.8f;
    enhanced_black_screen_reset_alert();
}

// // black_screen_detector.cpp - AMB82 Black Screen Detection Implementation
// #include "black_screen_detector.h"
// #include "lora_rak3172.h"
// #include "amb82_gpio.h"
// #include "amb82_flash.h"

// // ===== GLOBAL VARIABLES =====
// black_screen_detector_t black_screen_detector = {0};
// // External video stream reference
// extern Video Camera;
// extern NNObjectDetection ObjDet;
// // ===== INITIALIZATION =====
// black_screen_result_t black_screen_init() {
//     INFO_PRINT("Initializing black screen detector...");
    
//     // Initialize detector state
//     black_screen_detector.enabled = system_config.black_screen_enabled;
//     black_screen_detector.consecutive_black_frames = 0;
//     black_screen_detector.last_check_time = 0;
//     black_screen_detector.black_screen_start_time = 0;
//     black_screen_detector.is_currently_black = false;
//     black_screen_detector.alert_triggered = false;
//     black_screen_detector.last_brightness_value = 1.0f;
//     black_screen_detector.total_checks = 0;
//     black_screen_detector.black_detections = 0;
//     black_screen_detector.initialized = true;
    
//     INFO_PRINT("Black screen detector initialized");
//     INFO_PRINT("- Enabled: " + String(black_screen_detector.enabled ? "YES" : "NO"));
//     INFO_PRINT("- Threshold: " + String(system_config.black_screen_threshold));
//     INFO_PRINT("- Duration: " + String(system_config.black_screen_duration_ms/1000) + "s");
    
//     return BLACK_SCREEN_SUCCESS;
// }

// // ===== FRAME ANALYSIS =====
// black_screen_result_t black_screen_analyze_frame() {
//     if (!black_screen_detector.enabled || !black_screen_detector.initialized) {
//         return BLACK_SCREEN_SUCCESS;
//     }
    
//     black_screen_detector.total_checks++;
    
//     // Get detection results from the neural network
//     std::vector<ObjectDetectionResult> results = ObjDet.getResult();
//     int count = ObjDet.getResultCount();
    
//     // Calculate frame brightness based on detection activity
//     float brightness = black_screen_calculate_brightness_from_results(results, count);
//     black_screen_detector.last_brightness_value = brightness;
    
//     // Check if frame is dark
//     bool is_dark = (brightness < system_config.black_screen_threshold);
    
//     // Update consecutive frame counter
//     if (is_dark) {
//         black_screen_detector.consecutive_black_frames++;
//         black_screen_detector.black_detections++;
        
//         if (!black_screen_detector.is_currently_black) {
//             // First dark frame detected
//             black_screen_detector.is_currently_black = true;
//             black_screen_detector.black_screen_start_time = millis();
//             DEBUG_PRINT(3, "Black screen started - brightness: " + String(brightness));
//         }
//     } else {
//         // Frame is not dark
//         if (black_screen_detector.is_currently_black) {
//             // Black screen ended
//             black_screen_detector.is_currently_black = false;
//             black_screen_detector.consecutive_black_frames = 0;
//             DEBUG_PRINT(3, "Black screen ended - brightness: " + String(brightness));
            
//             // Reset alert if it was triggered
//             if (black_screen_detector.alert_triggered) {
//                 black_screen_reset_alert();
//             }
//         }
//     }
    
//     return BLACK_SCREEN_SUCCESS;
// }

// // ===== BRIGHTNESS CALCULATION =====
// float black_screen_calculate_brightness_from_results(std::vector<ObjectDetectionResult>& results, int result_count) {
//     // Method 1: If we have active detections, assume the frame is bright enough
//     if (result_count > 0) {
//         float total_confidence = 0.0f;
//         for (int i = 0; i < result_count && i < 5; i++) {
//             total_confidence += results[i].score();
//         }
//         // High detection confidence suggests good lighting
//         float avg_confidence = total_confidence / result_count;
//         return 0.3f + (avg_confidence * 0.7f); // Scale to 0.3-1.0 range
//     }
    
//     // Method 2: No detections could mean either:
//     // - Very dark frame (vandalism)
//     // - Normal frame with no objects
//     // We'll use a time-based approach for this case
    
//     static uint32_t frames_without_detection = 0;
//     static uint32_t last_detection_time = millis();
    
//     frames_without_detection++;
    
//     // If we haven't had detections for a while, and this pattern continues,
//     // it might indicate a black screen
//     uint32_t time_since_last_detection = millis() - last_detection_time;
    
//     if (frames_without_detection > 10 && time_since_last_detection > 10000) {
//         // No detections for 10+ frames and 10+ seconds - likely black screen
//         return 0.05f; // Very low brightness
//     } else if (frames_without_detection > 5 && time_since_last_detection > 5000) {
//         // Fewer detections recently - moderately suspicious
//         return 0.15f; // Low brightness
//     } else {
//         // Reset counter when we get back to normal
//         if (result_count > 0) {
//             frames_without_detection = 0;
//             last_detection_time = millis();
//         }
//         return 0.5f; // Assume normal brightness
//     }
// }

// // ===== PROCESSING AND ALERTS =====
// void black_screen_process() {
//     if (!black_screen_detector.enabled || !black_screen_detector.initialized) {
//         return;
//     }
    
//     uint32_t current_time = millis();
    
//     // Only check every 5 seconds to avoid excessive processing
//     if (current_time - black_screen_detector.last_check_time < 5000) {
//         return;
//     }
    
//     black_screen_detector.last_check_time = current_time;
    
//     // Analyze current frame
//     black_screen_analyze_frame();
    
//     // MAINTAIN LASER STATE DURING BLACK SCREEN EVENT
//     if (black_screen_detector.is_currently_black && black_screen_detector.alert_triggered) {
//         // Keep laser forced ON during entire black screen event
//         if (gpio_is_initialized()) {
//             gpio_laser_force_on();
//         }
        
//         // Send periodic vandalism alerts every 30 seconds
//         static uint32_t last_periodic_alert = 0;
//         if (current_time - last_periodic_alert > 30000) {
//             if (lora_is_initialized()) {
//                 char ongoing_alert[50];
//                 snprintf(ongoing_alert, sizeof(ongoing_alert), 
//                          "VANDALISM_ONGOING,%.2f,%lu", 
//                          black_screen_detector.last_brightness_value,
//                          (current_time - black_screen_detector.black_screen_start_time)/1000);
//                 lora_send_message(LORA_MSG_ALERT, ongoing_alert);
//             }
//             Serial.println("🔴 Vandalism event ongoing - laser still active");
//             last_periodic_alert = current_time;
//         }
//     }
    
//     // Check if we should trigger an alert for the first time
//     if (black_screen_detector.is_currently_black && 
//         !black_screen_detector.alert_triggered) {
        
//         uint32_t black_duration = current_time - black_screen_detector.black_screen_start_time;
        
//         if (black_duration >= system_config.black_screen_duration_ms) {
//             black_screen_handle_detection();
//         }
//     }
// }

// void black_screen_handle_detection() {
//     if (black_screen_detector.alert_triggered) {
//         return; // Alert already active
//     }
    
//     black_screen_detector.alert_triggered = true;
//     system_config.total_black_screen_events++;
//     system_config.last_black_screen_time = millis();
    
//     Serial.println("🚨 BLACK SCREEN DETECTION ALERT! (POSSIBLE VANDALISM)");
//     Serial.println("📹 Camera may be covered or damaged");
//     Serial.println("⏱️ Duration: " + String(system_config.black_screen_duration_ms/1000) + " seconds");
//     Serial.println("💡 Brightness: " + String(black_screen_detector.last_brightness_value));
//     Serial.println("🔴 CROSSHAIR LASER ACTIVATED FOR DETERRENT!");
    
//     // Create detection result for logging
//     detection_result_t det_result = {0};
//     det_result.timestamp = millis();
//     det_result.object_class = CLASS_BLACK_SCREEN;
//     det_result.confidence = 1.0f - black_screen_detector.last_brightness_value; // Higher confidence for darker images
//     det_result.x_min = 0;
//     det_result.y_min = 0;
//     det_result.x_max = 1;
//     det_result.y_max = 1;
//     det_result.valid = 1;
    
//     // Log to flash
//     if (flash_is_initialized()) {
//         flash_write_detection_log(&det_result);
//     }
    
//     // VANDALISM DETERRENT SYSTEM ACTIVATION
//     if (gpio_is_initialized()) {
//         // Set aggressive alert pattern for black screen
//         gpio_status_led_set_pattern(LED_PATTERN_FAST_BLINK);
        
//         // FORCE CROSSHAIR LASER ON - VANDALISM DETERRENT
//         // This laser will stay ON until black screen is removed
//         gpio_laser_force_on();
//         Serial.println("🎯 Crosshair laser FORCED ON as vandalism deterrent");
        
//         // Optional: Create audible alarm using fan pin
//         // Rapid fan pulses can create attention-getting sound
//         // Disable normal fan operation during vandalism event
//         gpio_fan_enable(false);
//     }
    
//     // Send LoRa vandalism alert with laser status
//     if (lora_is_initialized()) {
//         char alert_msg[60];
//         snprintf(alert_msg, sizeof(alert_msg), 
//                  "VANDALISM,%.2f,%lu,LASER_ON", 
//                  black_screen_detector.last_brightness_value,
//                  system_config.black_screen_duration_ms/1000);
        
//         lora_result_t result = lora_send_message(LORA_MSG_ALERT, alert_msg);
//         if (result == LORA_SUCCESS) {
//             Serial.println("📡 Vandalism alert with laser status sent via LoRa");
//         } else {
//             Serial.println("❌ Failed to send vandalism alert via LoRa");
//         }
//     }
// }

// void black_screen_reset_alert() {
//     if (black_screen_detector.alert_triggered) {
//         uint32_t vandalism_duration = millis() - black_screen_detector.black_screen_start_time;
        
//         black_screen_detector.alert_triggered = false;
        
//         Serial.println("✅ BLACK SCREEN CLEARED - VANDALISM EVENT ENDED");
//         Serial.println("📹 Normal camera vision restored");
//         Serial.println("🔴 CROSSHAIR LASER DEACTIVATED");
//         Serial.println("⏱️ Total vandalism duration: " + String(vandalism_duration/1000) + " seconds");
        
//         // DEACTIVATE VANDALISM DETERRENT SYSTEM
//         if (gpio_is_initialized()) {
//             // Turn OFF the crosshair laser
//             gpio_laser_force_off();
            
//             // Reset status LED to normal operation
//             gpio_status_led_set_pattern(LED_PATTERN_SLOW_BLINK);
            
//             // Re-enable normal fan operation
//             gpio_fan_enable(system_config.fan_enabled);
            
//             Serial.println("🎯 All deterrent systems deactivated - resuming normal operation");
//         }
        
//         // Send vision restored notification with event summary
//         if (lora_is_initialized()) {
//             char recovery_msg[70];
//             snprintf(recovery_msg, sizeof(recovery_msg), 
//                      "VISION_RESTORED,LASER_OFF,%lu", 
//                      vandalism_duration/1000);
//             lora_send_message(LORA_MSG_ALERT, recovery_msg);
//             Serial.println("📡 Vision restoration notification sent via LoRa");
//         }
        
//         // Log the end of vandalism event
//         if (flash_is_initialized()) {
//             detection_result_t recovery_result = {0};
//             recovery_result.timestamp = millis();
//             recovery_result.object_class = CLASS_BLACK_SCREEN;
//             recovery_result.confidence = 0.0f; // 0 confidence indicates end of event
//             recovery_result.x_min = vandalism_duration; // Store duration in x_min field
//             recovery_result.valid = 1;
//             flash_write_detection_log(&recovery_result);
//         }
//     }
// }

// // ===== CONFIGURATION FUNCTIONS =====
// black_screen_result_t black_screen_set_threshold(float threshold) {
//     if (threshold < 0.0f || threshold > 1.0f) {
//         return BLACK_SCREEN_ERROR_PROCESSING;
//     }
    
//     system_config.black_screen_threshold = threshold;
//     INFO_PRINT("Black screen threshold set to " + String(threshold));
//     return BLACK_SCREEN_SUCCESS;
// }

// black_screen_result_t black_screen_set_duration(uint32_t duration_ms) {
//     if (duration_ms < 1000 || duration_ms > 60000) {
//         return BLACK_SCREEN_ERROR_PROCESSING;
//     }
    
//     system_config.black_screen_duration_ms = duration_ms;
//     INFO_PRINT("Black screen duration set to " + String(duration_ms/1000) + " seconds");
//     return BLACK_SCREEN_SUCCESS;
// }

// black_screen_result_t black_screen_enable(bool enable) {
//     black_screen_detector.enabled = enable;
//     system_config.black_screen_enabled = enable;
    
//     if (!enable && black_screen_detector.alert_triggered) {
//         black_screen_reset_alert();
//     }
    
//     INFO_PRINT("Black screen detection " + String(enable ? "enabled" : "disabled"));
//     return BLACK_SCREEN_SUCCESS;
// }

// // ===== STATUS FUNCTIONS =====
// bool black_screen_is_enabled() {
//     return black_screen_detector.enabled;
// }

// bool black_screen_is_alert_active() {
//     return black_screen_detector.alert_triggered;
// }

// bool black_screen_is_laser_deterrent_active() {
//     return black_screen_detector.alert_triggered && black_screen_detector.is_currently_black;
// }

// float black_screen_get_last_brightness() {
//     return black_screen_detector.last_brightness_value;
// }

// uint32_t black_screen_get_detection_count() {
//     return black_screen_detector.black_detections;
// }

// void black_screen_print_stats() {
//     Serial.println("\n=== BLACK SCREEN DETECTOR STATS ===");
//     Serial.println("Enabled: " + String(black_screen_detector.enabled ? "YES" : "NO"));
//     Serial.println("Alert Active: " + String(black_screen_detector.alert_triggered ? "YES" : "NO"));
//     Serial.println("Currently Black: " + String(black_screen_detector.is_currently_black ? "YES" : "NO"));
//     Serial.println("Laser Active: " + String(black_screen_detector.alert_triggered ? "YES (DETERRENT)" : "NO"));
//     Serial.println("Threshold: " + String(system_config.black_screen_threshold));
//     Serial.println("Duration: " + String(system_config.black_screen_duration_ms/1000) + "s");
//     Serial.println("Last Brightness: " + String(black_screen_detector.last_brightness_value));
//     Serial.println("Total Checks: " + String(black_screen_detector.total_checks));
//     Serial.println("Black Detections: " + String(black_screen_detector.black_detections));
//     Serial.println("Total Events: " + String(system_config.total_black_screen_events));
//     Serial.println("Consecutive Frames: " + String(black_screen_detector.consecutive_black_frames));
    
//     if (black_screen_detector.is_currently_black) {
//         uint32_t current_duration = (millis() - black_screen_detector.black_screen_start_time) / 1000;
//         Serial.println("Current Event Duration: " + String(current_duration) + "s");
//     }
    
//     if (system_config.last_black_screen_time > 0) {
//         Serial.println("Last Event: " + String((millis() - system_config.last_black_screen_time)/1000) + "s ago");
//     } else {
//         Serial.println("Last Event: Never");
//     }
    
//     Serial.println("\n🎯 VANDALISM DETERRENT STATUS:");
//     if (black_screen_detector.alert_triggered) {
//         Serial.println("🔴 ACTIVE - Crosshair laser deterrent is ON");
//         Serial.println("⚠️  Laser will remain ON until vision is restored");
//     } else {
//         Serial.println("🟢 INACTIVE - Normal laser operation");
//     }
    
//     Serial.println("===================================\n");
// }

// // ===== MANUAL CONTROL FUNCTIONS (for testing and emergency override) =====
// void black_screen_force_alert_test() {
//     Serial.println("🧪 FORCING BLACK SCREEN ALERT FOR TESTING");
//     black_screen_detector.is_currently_black = true;
//     black_screen_detector.black_screen_start_time = millis() - system_config.black_screen_duration_ms;
//     black_screen_handle_detection();
// }

// void black_screen_force_clear_test() {
//     Serial.println("🧪 FORCING BLACK SCREEN CLEAR FOR TESTING");
//     black_screen_detector.is_currently_black = false;
//     black_screen_reset_alert();
// }