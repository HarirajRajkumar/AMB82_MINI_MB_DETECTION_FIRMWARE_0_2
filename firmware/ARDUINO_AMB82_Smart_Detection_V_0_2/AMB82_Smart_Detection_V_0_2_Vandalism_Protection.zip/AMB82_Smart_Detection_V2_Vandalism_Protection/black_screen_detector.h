// black_screen_detector.h - AMB82 Black Screen Detection for Vandalism Protection
#ifndef BLACK_SCREEN_DETECTOR_H
#define BLACK_SCREEN_DETECTOR_H

#include "config.h"
#include "NNObjectDetection.h"
#include <vector>

// ===== BLACK SCREEN DETECTION RESULTS =====
typedef enum {
    BLACK_SCREEN_SUCCESS = 0,
    BLACK_SCREEN_ERROR_INIT,
    BLACK_SCREEN_ERROR_NO_FRAME,
    BLACK_SCREEN_ERROR_PROCESSING
} black_screen_result_t;

// ===== BLACK SCREEN DETECTION STATE =====
typedef struct {
    bool enabled;
    bool initialized;
    uint32_t consecutive_black_frames;
    uint32_t last_check_time;
    uint32_t black_screen_start_time;
    bool is_currently_black;
    bool alert_triggered;
    float last_brightness_value;
    uint32_t total_checks;
    uint32_t black_detections;
} black_screen_detector_t;

// ===== FUNCTION DECLARATIONS =====
black_screen_result_t black_screen_init();
black_screen_result_t black_screen_analyze_frame();
float black_screen_calculate_brightness_from_results(std::vector<ObjectDetectionResult>& results, int result_count);
void black_screen_process();
void black_screen_handle_detection();
void black_screen_reset_alert();
void black_screen_print_stats();
void black_screen_force_alert_test();
void black_screen_force_clear_test();

// Configuration functions
black_screen_result_t black_screen_set_threshold(float threshold);
black_screen_result_t black_screen_set_duration(uint32_t duration_ms);
black_screen_result_t black_screen_enable(bool enable);

// Status functions
bool black_screen_is_enabled();
bool black_screen_is_alert_active();
bool black_screen_is_laser_deterrent_active();
float black_screen_get_last_brightness();
uint32_t black_screen_get_detection_count();

// Global detector instance
extern black_screen_detector_t black_screen_detector;

// External references to main system objects
extern NNObjectDetection ObjDet;

#endif // BLACK_SCREEN_DETECTOR_H